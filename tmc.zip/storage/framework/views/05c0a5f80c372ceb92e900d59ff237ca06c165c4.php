
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\xampp\htdocs\thaiever\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>