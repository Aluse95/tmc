
<?php echo $__env->yieldContent('content'); ?>
<?php /**PATH C:\xampp\htdocs\xkld\resources\views/frontend/blocks/main/index.blade.php ENDPATH**/ ?>